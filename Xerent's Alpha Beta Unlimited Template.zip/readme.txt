xerent's A/B/Unl template

Please note that it is illegal and violates the copyright of Wizards of the Coast to sell proxies. This template is provided so that you can create proxies for your own personal use. This template is unsanctioned and unaffiliated with Wizards of the Coast.